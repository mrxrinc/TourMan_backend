const SECRET_KEY = 'TourMan_mrxrinc'

module.exports = SECRET_KEY